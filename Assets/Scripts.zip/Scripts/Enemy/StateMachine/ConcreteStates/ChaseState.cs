using UnityEngine;

public class ChaseState : EnemyState
{
    public ChaseState(Enemy enemy, EnemyStateMachine stateMachine) : base(enemy, stateMachine)
    {
    }

    public override void Enter()
    {
        enemy.animator.SetBool("isChasing", true);
    }

    public override void Exit()
    {
        enemy.animator.SetBool("isChasing", false);
    }

    public override void FrameUpdate()
    {
        if (!enemy.detectionSystem.IsPlayerDetected())
        {
            stateMachine.ChangeState(enemy.waitState);
            return;
        }
    }

    public override void PhysicsUpdate()
    {
        if (enemy.playerTransform == null) return;

        Vector2 dir = (enemy.playerTransform.position - enemy.transform.position);
        float distanceToPlayer = dir.magnitude;

        // --- CORRE��O DO SAMBA (Flip) ---
        if (Mathf.Abs(dir.x) > 0.2f)
        {
            if (dir.x > 0 && !enemy.isFacingRight) enemy.Flip();
            else if (dir.x < 0 && enemy.isFacingRight) enemy.Flip();
        }

        // L�gica de Ataque
        if (distanceToPlayer <= enemy.data.attackDistance && ((Bat)enemy).canAttack)
        {
            // Importante: Zere a velocidade/in�rcia ao atacar
            enemy.rb.linearVelocity = Vector2.zero;
            stateMachine.ChangeState(((Bat)enemy).attackState);
            return;
        }
        // L�gica de Movimento
        else if (distanceToPlayer > enemy.data.stopDistance)
        {
            // MovePosition � mais est�vel que AddForce para RPGs
            // Calculamos a nova posi��o baseada na velocidade * tempo fixo
            Vector2 targetPosition = enemy.rb.position + (dir.normalized * enemy.data.moveSpeed * Time.fixedDeltaTime);

            enemy.rb.MovePosition(targetPosition);
        }
        // Parado
        else
        {
            // Se j� chegou perto, garanta que ele n�o deslize
            enemy.rb.linearVelocity = Vector2.zero;
        }
    }
}
