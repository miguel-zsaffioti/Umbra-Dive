using System.Collections;
using UnityEngine;

public class FlashEffect : MonoBehaviour
{
    [Header("Configura��es")]
    [Tooltip("Arraste o material branco que voc� criou aqui")]
    public Material whiteMaterial;
    [Tooltip("Dura��o do flash (0.1s � ideal para Moonlighter)")]
    public float duration = 0.1f;

    private SpriteRenderer spriteRenderer;
    private Material originalMaterial;
    private Coroutine flashRoutine;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalMaterial = spriteRenderer.material;
    }

    public void Flash()
    {
        if (flashRoutine != null)
        {
            StopCoroutine(flashRoutine);
        }
        flashRoutine = StartCoroutine(FlashRoutine());
    }

    private IEnumerator FlashRoutine()
    {
        spriteRenderer.material = whiteMaterial;
        yield return new WaitForSeconds(duration);
        spriteRenderer.material = originalMaterial;

        flashRoutine = null;
    }
}