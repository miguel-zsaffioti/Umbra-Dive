﻿using UnityEngine;
using UnityEngine.InputSystem;

public class WalkState : PlayerState
{
    public WalkState(Player player, PlayerStateMachine stateMachine) : base(player, stateMachine)
    {
    }
    public override void Enter()
    {
        animator.SetBool("isWalking", true);
    }

    public override void FrameUpdate()
    {
        base.FrameUpdate();
        if (inputSystem.AttackInput)
        {
            stateMachine.ChangeState(player.attackState);
            return;
        }
        if (inputSystem.BlockInput)
        {
            stateMachine.ChangeState(player.blockState);
            return;
        }
        if (inputSystem.RollInput && player.rollCooldown.IsReady)
        {
            stateMachine.ChangeState(player.rollState);
            return;
        }
        if (inputSystem.MoveInput == Vector2.zero)
        {
            stateMachine.ChangeState(player.idleState);
            return;
        }
        
    }

    public override void HandleAnimation()
    {
        Vector2 moveInput = inputSystem.MoveInput;

        animator.SetFloat("XInput", moveInput.x);
        animator.SetFloat("YInput", moveInput.y);

        if (moveInput.magnitude > 0.1f)
        {
            animator.SetFloat("LastX", moveInput.x);
            animator.SetFloat("LastY", moveInput.y);
        }
    }

    public override void PhysicsUpdate()
    {
        player.facingDirection = inputSystem.MoveInput.normalized;
        rb.linearVelocity = inputSystem.MoveInput.normalized * player.moveSpeed;
    }
}
